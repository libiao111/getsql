<?php 
function p($arr)
{
	dump($arr,1,'',0);
}
?>